package com.someday.faq;

import com.someday.faq.FAQModel;

public interface FAQDAO {
	
	FAQModel faq();

}
