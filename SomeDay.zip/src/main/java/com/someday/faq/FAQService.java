package com.someday.faq;

public class FAQService {

}
