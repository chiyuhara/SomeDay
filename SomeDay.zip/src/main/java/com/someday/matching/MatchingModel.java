package com.someday.matching;

public class MatchingModel {
	int small;

	public int getSmall() {
		return small;
	}

	public void setSmall(int small) {
		this.small = small;
	}
}
