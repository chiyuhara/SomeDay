package com.someday.meeting;

import java.util.List;

public interface MeetDao {
	
	//������Ȳ
	public List<MeetModel> meetingList();

	
}
