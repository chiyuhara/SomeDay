if (typeof wcs == "undefined") {
	wcs = {}
}
if (!wcs_SerName) {
	var wcs_SerName = "wcs.naver.com"
}
if (typeof wcs_add == "undefined") {
	var wcs_add = {}
}
if (typeof wcs.ref == "undefined") {
	wcs.ref = ""
}
if (typeof wcs.bt == "undefined") {
	wcs.bt = -1
}
if (typeof wcs.norefresh == "undefined") {
	wcs.norefresh = 0
}
(function() {
	var R = {}, o = "0.4.28", k = navigator, av = window.location, w = av.href, aq = av.search, j = av.hostname, T = av.pathname, C = document.referrer, ai = k.appName, p = k.appVersion, c = k.userAgent, H = (ai == "Microsoft Internet Explorer"), f = (p
			.indexOf("Opera") >= 0), E = (c.indexOf("MAC") >= 0), au = 0, u = -1, q = encodeURIComponent, t = decodeURIComponent, i = (av.protocol == "https:") ? "https:"
			: "http:", ag = "NA_SA", af = "NA_SAC", ad = "NA_SAS", Q = "NA_MI", U = "NA_CO", P = "NVADID", ab = "CPAValidator", W = [], G = "wcs.cr2.shopping.naver.com";
	function at() {
		s();
		g();
		ah();
		V();
		r();
		m();
		aw();
		Z();
		I();
		aa();
		v()
	}
	function s() {
		R.os = k.platform ? k.platform : ""
	}
	function g() {
		var ax = "";
		ax = k.userLanguage ? k.userLanguage : (k.language ? k.language : "");
		R.ln = ax
	}
	function ah() {
		var ay = "";
		if (window.screen && screen.width && screen.height) {
			ay = screen.width + "x" + screen.height
		} else {
			if (window.java || self.java) {
				var ax = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
				ay = ax.width + "x" + ax.height
			}
		}
		R.sr = ay
	}
	function V() {
		try {
			R.bw = document.documentElement.clientWidth ? document.documentElement.clientWidth
					: document.body.clientWidth;
			R.bh = document.documentElement.clientHeight ? document.documentElement.clientHeight
					: document.body.clientHeight
		} catch (ax) {
		}
	}
	function r() {
		R.c = "";
		if (window.screen) {
			R.c = screen.colorDepth ? screen.colorDepth : screen.pixelDepth
		} else {
			if (window.java || self.java) {
				var ax = java.awt.Toolkit.getDefaultToolkit().getColorModel()
						.getPixelSize();
				R.c = ax
			}
		}
	}
	function m() {
		R.j = "";
		try {
			R.j = k.javaEnabled() ? "Y" : "N"
		} catch (ax) {
		}
	}
	function Z() {
		if (k.cookieEnabled) {
			R.k = "Y"
		} else {
			R.k = "N"
		}
	}
	function I() {
		var ax = "";
		try {
			if (H && !E && document.body) {
				var az = document.body.addBehavior("#default#clientCaps");
				if (document.body.connectionType) {
					ax = document.body.connectionType
				}
				document.body.removeBehavior(az)
			}
		} catch (ay) {
		}
		R.ct = ax
	}
	function aw() {
		var az = "1.0";
		try {
			if (String && String.prototype) {
				az = "1.1";
				if (az.search) {
					az = "1.2";
					var ay = new Date, aF = 0;
					if (ay.getUTCDate) {
						az = "1.3";
						var aB, ax = p.indexOf("MSIE");
						if (ax > 0) {
							var aG = parseInt(aB = p.substring(ax + 5));
							if (aG > 3) {
								aG = parseFloat(aB)
							}
						}
						if (H && E && aG >= 5) {
							az = "1.4"
						}
						if (aF.toFixed) {
							az = "1.5";
							var aE = new Array;
							if (aE.every) {
								az = "1.6";
								aB = 0;
								var aA = new Object;
								var aD = function(aJ) {
									var aH = 0;
									try {
										aH = new Iterator(aJ)
									} catch (aI) {
									}
									return aH
								};
								aB = aD(aA);
								if (aB && aB.next) {
									az = "1.7"
								}
								if (aE.reduce) {
									az = "1.8"
								}
							}
						}
					}
				}
			}
		} catch (aC) {
		}
		R.jv = az
	}
	function aa() {
		R.cs = document.characterSet || document.charset || "-"
	}
	function v() {
		R.tl = q(document.title.substring(0, 128))
	}
	function aj(ax) {
		return ax.replace(/^\s\s*/, "").replace(/\s\s*$/, "")
	}
	function Y(aL, aB) {
		var aK = "wcs_bt";
		var aA = "";
		var aF = new Date();
		var aQ = "";
		var aD = "/";
		var aM = -1;
		var aE, ax, aN, aR, aG, aI;
		var aC = {};
		if ((j == "storefarm.naver.com") || (j == "m.storefarm.naver.com")) {
			al(aK, "", aD);
			var aH = T.split("/");
			if (aH.length > 2) {
				aD = "/" + aH[1]
			} else {
				aD = T
			}
		}
		aE = l(aK, 1);
		for ( var aO in aE) {
			if (Object.prototype.hasOwnProperty.call(aE, aO)) {
				if (aE[aO].indexOf(":") >= 0) {
					ax = aE[aO].split("|");
					for ( var aP in ax) {
						if (Object.prototype.hasOwnProperty.call(ax, aP)) {
							aN = ax[aP].split(":");
							var aJ = 0;
							for ( var ay in aN) {
								if (Object.prototype.hasOwnProperty
										.call(aN, ay)) {
									if (aJ == 0) {
										aR = aN[ay]
									} else {
										if (aJ == 1) {
											aG = aN[ay]
										}
									}
									aJ++
								}
							}
							aC[aR] = aG;
							if (aR == aB && aM < aG) {
								aM = aG
							}
						}
					}
					if (wcs.bt > aM) {
						aM = wcs.bt
					}
				} else {
					if (aM < aE[aO]) {
						aM = aE[aO];
						wcs.bt = aM;
						aC[aB] = aM
					}
				}
			}
		}
		aF.setDate(aL.getDate() + 200 * 365);
		aQ = aF.toGMTString();
		aI = 0;
		for ( var az in aC) {
			if (az == aB) {
				aA += az + ":" + parseInt(aL.getTime() / 1000).toString() + "|";
				aI++
			} else {
				aA += az + ":" + aC[az] + "|"
			}
		}
		if (aI == 0) {
			aA += aB + ":" + parseInt(aL.getTime() / 1000).toString() + "|"
		}
		if (aA != "") {
			aA = aA.substring(0, aA.length - 1)
		}
		ae(aK, aA, "", aQ, aD);
		return aM
	}
	function l(aE, aD) {
		var az = "";
		var ay = [];
		var aG = document.cookie.split(";");
		var aF = aG.length;
		var aA = false;
		var aB = "";
		var ax;
		for (var aC = 0; aC < aF; aC++) {
			aB = aj(aG[aC]);
			if (aB.indexOf(aE + "=") == 0) {
				az = aB.substring(aB.indexOf("=") + 1);
				ay.push(az);
				aA = true;
				if (aD != 1) {
					break
				}
			}
		}
		if (aA && aD == 1) {
			ax = ay
		} else {
			if (aA) {
				ax = az
			} else {
				ax = false
			}
		}
		return ax
	}
	function ae(aB, aA, ax, ay, az) {
		document.cookie = aB + "=" + aA + ((!ay) ? "" : "; expires=" + ay)
				+ "; path=" + ((!az) ? "/" : az)
				+ ((!ax) ? "" : "; domain=" + ax)
	}
	function al(aB, ax, aA) {
		var az = new Date();
		az.setDate(az.getDate() - 1);
		var ay = az.toGMTString();
		ae(aB, "", ax, ay, aA)
	}
	var h;
	if (!h) {
		h = {}
	}
	(function() {
		function aA(aG) {
			return aG < 10 ? "0" + aG : aG
		}
		if (typeof Date.prototype.toJSON !== "function") {
			Date.prototype.toJSON = function(aG) {
				var aH = ((!(typeof this.valueOf == "undefined")) && isFinite(this
						.valueOf())) ? this.getUTCFullYear() + "-"
						+ aA(this.getUTCMonth() + 1) + "-"
						+ aA(this.getUTCDate()) + "T" + aA(this.getUTCHours())
						+ ":" + aA(this.getUTCMinutes()) + ":"
						+ aA(this.getUTCSeconds()) + "Z" : null;
				return aH
			};
			if (!(typeof this.valueOf == "undefined")) {
				String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function(
						aG) {
					return this.valueOf()
				}
			}
		}
		var az = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, aC = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, aD, ay, aF = {
			"\b" : "\\b",
			"\t" : "\\t",
			"\n" : "\\n",
			"\f" : "\\f",
			"\r" : "\\r",
			'"' : '\\"',
			"\\" : "\\\\"
		}, aE;
		function ax(aG) {
			aC.lastIndex = 0;
			return aC.test(aG) ? '"'
					+ aG.replace(aC, function(aH) {
						var aI = aF[aH];
						return typeof aI === "string" ? aI : "\\u"
								+ ("0000" + aH.charCodeAt(0).toString(16))
										.slice(-4)
					}) + '"' : '"' + aG + '"'
		}
		function aB(aN, aK) {
			var aI, aH, aO, aG, aL = aD, aJ, aM = aK[aN];
			if (aM && typeof aM === "object" && typeof aM.toJSON === "function") {
				aM = aM.toJSON(aN)
			}
			if (typeof aE === "function") {
				aM = aE.call(aK, aN, aM)
			}
			switch (typeof aM) {
			case "string":
				return ax(aM);
			case "number":
				return isFinite(aM) ? String(aM) : "null";
			case "boolean":
			case "null":
				return String(aM);
			case "object":
				if (!aM) {
					return "null"
				}
				aD += ay;
				aJ = [];
				if (Object.prototype.toString.apply(aM) === "[object Array]") {
					aG = aM.length;
					for (aI = 0; aI < aG; aI += 1) {
						aJ[aI] = aB(aI, aM) || "null"
					}
					aO = aJ.length === 0 ? "[]" : aD ? "[\n" + aD
							+ aJ.join(",\n" + aD) + "\n" + aL + "]" : "["
							+ aJ.join(",") + "]";
					aD = aL;
					return aO
				}
				if (aE && typeof aE === "object") {
					aG = aE.length;
					for (aI = 0; aI < aG; aI += 1) {
						if (typeof aE[aI] === "string") {
							aH = aE[aI];
							aO = aB(aH, aM);
							if (aO) {
								aJ.push(ax(aH) + (aD ? ": " : ":") + aO)
							}
						}
					}
				} else {
					for (aH in aM) {
						if (Object.prototype.hasOwnProperty.call(aM, aH)) {
							aO = aB(aH, aM);
							if (aO) {
								aJ.push(ax(aH) + (aD ? ": " : ":") + aO)
							}
						}
					}
				}
				aO = aJ.length === 0 ? "{}" : aD ? "{\n" + aD
						+ aJ.join(",\n" + aD) + "\n" + aL + "}" : "{"
						+ aJ.join(",") + "}";
				aD = aL;
				return aO
			}
		}
		if (typeof h.stringify !== "function") {
			h.stringify = function(aJ, aH, aI) {
				var aG;
				aD = "";
				ay = "";
				if (typeof aI === "number") {
					for (aG = 0; aG < aI; aG += 1) {
						ay += " "
					}
				} else {
					if (typeof aI === "string") {
						ay = aI
					}
				}
				aE = aH;
				if (aH
						&& typeof aH !== "function"
						&& (typeof aH !== "object" || typeof aH.length !== "number")) {
					throw new Error("JSON.stringify")
				}
				return aB("", {
					"" : aJ
				})
			}
		}
	}());
	var am = {
		_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
		encode : function(az) {
			var ax = "";
			var aG, aE, aC, aF, aD, aB, aA;
			var ay = 0;
			az = am._utf8_encode(az);
			while (ay < az.length) {
				aG = az.charCodeAt(ay++);
				aE = az.charCodeAt(ay++);
				aC = az.charCodeAt(ay++);
				aF = aG >> 2;
				aD = ((aG & 3) << 4) | (aE >> 4);
				aB = ((aE & 15) << 2) | (aC >> 6);
				aA = aC & 63;
				if (isNaN(aE)) {
					aB = aA = 64
				} else {
					if (isNaN(aC)) {
						aA = 64
					}
				}
				ax = ax + this._keyStr.charAt(aF) + this._keyStr.charAt(aD)
						+ this._keyStr.charAt(aB) + this._keyStr.charAt(aA)
			}
			return ax
		},
		decode : function(az) {
			var ax = "";
			var aG, aE, aC;
			var aF, aD, aB, aA;
			var ay = 0;
			az = az.replace(/[^A-Za-z0-9\+\/\=]/g, "");
			while (ay < az.length) {
				aF = this._keyStr.indexOf(az.charAt(ay++));
				aD = this._keyStr.indexOf(az.charAt(ay++));
				aB = this._keyStr.indexOf(az.charAt(ay++));
				aA = this._keyStr.indexOf(az.charAt(ay++));
				aG = (aF << 2) | (aD >> 4);
				aE = ((aD & 15) << 4) | (aB >> 2);
				aC = ((aB & 3) << 6) | aA;
				ax = ax + String.fromCharCode(aG);
				if (aB != 64) {
					ax = ax + String.fromCharCode(aE)
				}
				if (aA != 64) {
					ax = ax + String.fromCharCode(aC)
				}
			}
			ax = am._utf8_decode(ax);
			return ax
		},
		_utf8_encode : function(ay) {
			ay = ay.replace(/\r\n/g, "\n");
			var ax = "";
			for (var aA = 0; aA < ay.length; aA++) {
				var az = ay.charCodeAt(aA);
				if (az < 128) {
					ax += String.fromCharCode(az)
				} else {
					if ((az > 127) && (az < 2048)) {
						ax += String.fromCharCode((az >> 6) | 192);
						ax += String.fromCharCode((az & 63) | 128)
					} else {
						ax += String.fromCharCode((az >> 12) | 224);
						ax += String.fromCharCode(((az >> 6) & 63) | 128);
						ax += String.fromCharCode((az & 63) | 128)
					}
				}
			}
			return ax
		},
		_utf8_decode : function(ax) {
			var ay = "";
			var aA = 0;
			var aC = 0, aB = 0, az = 0;
			while (aA < ax.length) {
				aC = ax.charCodeAt(aA);
				if (aC < 128) {
					ay += String.fromCharCode(aC);
					aA++
				} else {
					if ((aC > 191) && (aC < 224)) {
						az = ax.charCodeAt(aA + 1);
						ay += String.fromCharCode(((aC & 31) << 6) | (az & 63));
						aA += 2
					} else {
						az = ax.charCodeAt(aA + 1);
						c3 = ax.charCodeAt(aA + 2);
						ay += String.fromCharCode(((aC & 15) << 12)
								| ((az & 63) << 6) | (c3 & 63));
						aA += 3
					}
				}
			}
			return ay
		}
	};
	function n(ax) {
		var ay = new Image(1, 1);
		ay.src = ax;
		ay.onload = function() {
			ay.onload = null;
			return
		};
		ay.onerror = function() {
			ay.onerror = null;
			return
		};
		return true
	}
	function J(aD, aC) {
		var ay = new Date();
		var ax = [];
		var aB;
		var aE = "unknown";
		ax.push(i + "//" + aC + "/m?");
		ax.push("u=" + q(w) + "&e=" + (C ? q(C) : ""));
		for (aB in wcs_add) {
			if (typeof wcs_add[aB] != "function" && (aB == "i" || aB == "wa")) {
				ax.push("&" + aB + "=" + q(wcs_add[aB]));
				if (aB == "wa") {
					aE = wcs_add[aB]
				}
			}
		}
		if (au < 1) {
			at()
		}
		u = Y(ay, aE);
		ax.push("&bt=" + u);
		for (aB in aD) {
			var aA = typeof aB;
			var az = typeof aD[aB];
			if ((aA == "string" && aB.length >= 3 && az != "function")
					|| aB == "qy") {
				if (az == "string") {
					ax.push("&" + aB + "=" + q(aD[aB]))
				} else {
					if (az == "object") {
						ax.push("&" + aB + "=" + q(h.stringify(aD[aB])))
					}
				}
			}
		}
		for (aB in R) {
			if (typeof R[aB] != "function") {
				ax.push("&" + aB + "=" + q(R[aB]))
			}
		}
		if (wcs.ref != "") {
			ax.push("&ur=" + q(wcs.ref))
		}
		ax.push("&vs=" + o + "&nt=" + ay.getTime());
		au++;
		return ax.join("")
	}
	wcs.pageview = function(ay) {
		var ax = J(ay, wcs_SerName);
		ax += "&EOU";
		n(ax)
	};
	wcs.event = function(ax, az) {
		var aA = [];
		var ay;
		if (ax == "" || az == "" || typeof ax == "undefined"
				|| typeof az == "undefined") {
			return
		}
		aA.push(i + "//" + wcs_SerName + "/m?");
		aA.push("u=" + q(w));
		aA.push("&t=event");
		for (ay in wcs_add) {
			if (typeof wcs_add[ay] != "function" && (ay == "i" || ay == "wa")) {
				aA.push("&" + ay + "=" + q(wcs_add[ay]))
			}
		}
		aA.push("&e_cat=" + q(ax));
		aA.push("&e_act=" + q(az));
		aA.push("&nt=" + (new Date().getTime()));
		n(aA.join(""));
		return true
	};
	function a() {
		if (aq.length <= 0 || aq.split("?").length < 2) {
			return false
		}
		var ay = aq.split("?")[1].split("&");
		var aA = ay.length;
		var ax;
		for (var az = 0; az < aA; az++) {
			ax = ay[az].split("=");
			if (ax[0] == "NaPm" && aj(ax[1]) != "") {
				return ax[1]
			}
		}
		return false
	}
	function S(ax) {
		var az = "/";
		var ay = ax.indexOf("/");
		if (ay > 0) {
			az = ax.substring(ay);
			ax = ax.substring(0, ay);
			return [ ax, az ]
		}
		return false
	}
	function ac(aF, aC, aH, aD, ay, aE, aG) {
		var az = [];
		az[0] = "NVKWD=" + aC;
		az[1] = "NVADKWD=" + aH;
		az[2] = "NVAR=" + aD;
		az[3] = "NVADID=" + ay;
		az[4] = "t=" + Math.round(aE.getTime() / 1000);
		az[5] = "u=" + q(w);
		az[6] = "r=" + q(C);
		var aA = az.join("|");
		aA = am.encode(aA);
		var ax = new Date();
		ax.setDate(aE.getDate() + 20);
		var aB = ax.toGMTString();
		ae(ag, aA, aF, aB, aG);
		ae(ad, "1", aF, 0, aG);
		ae(P, ay, aF, aB)
	}
	function d(ay) {
		if (!ay) {
			wcs.norefresh++;
			return false
		}
		if (wcs.norefresh > 0) {
			return false
		}
		ay = am.decode(ay);
		var aB = ay.split("|");
		var aA = aB.length;
		var aC;
		var ax = 0;
		for (var az = 0; az < aA; az++) {
			aC = aB[az].split("=");
			if (aC[0] == "u") {
				if (t(aC[1]) == w) {
					ax++
				}
			} else {
				if (aC[0] == "r") {
					if (t(aC[1]) == C) {
						ax++
					}
				}
			}
		}
		if (ax == 2) {
			return true
		}
		wcs.norefresh++;
		return false
	}
	function y(aI) {
		var aG = new Date();
		var aJ = "/";
		if (!aI) {
			aI = ""
		} else {
			var aH = S(aI);
			if (aH != false) {
				aI = aH[0];
				aJ = aH[1]
			}
			if (j.indexOf(aI) < 0) {
				aI = ""
			}
		}
		var ay = "", aK = "", az = "", ax = "";
		var aF = "", aE;
		if (aq.length <= 0 || aq.split("?").length < 2) {
			return false
		}
		var aD = aq.split("?")[1].split("&");
		var aC = aD.length;
		var aB;
		for (var aA = 0; aA < aC; aA++) {
			aB = aD[aA].split("=");
			if (aB[0] == "NaPm") {
				aF = aB[1]
			} else {
				if (aB[0] == "NVKWD") {
					ay = aB[1]
				} else {
					if (aB[0] == "NVADKWD") {
						aK = aB[1]
					} else {
						if (aB[0] == "NVAR") {
							az = aB[1]
						} else {
							if (aB[0] == "NVADID") {
								ax = aB[1]
							}
						}
					}
				}
			}
		}
		if (aF != "") {
			aE = x(aF);
			if (aE.NVKWD) {
				ay = aE.NVKWD
			}
			if (aE.NVADKWD) {
				aK = aE.NVADKWD
			}
			if (aE.NVAR) {
				az = aE.NVAR
			}
			if (aE.NVADID) {
				ax = aE.NVADID
			}
		}
		if (ax != "" && az != "") {
			ac(aI, ay, aK, az, ax, aG, aJ)
		}
	}
	function M(aB, aL) {
		var aJ = new Date();
		var aG = [];
		var aK = l(ag);
		if (aK == false) {
			return ""
		}
		var aH = l(af);
		if (d(aH)) {
			return ""
		}
		var aI = "0";
		if (l(ad) == "1") {
			aI = "1"
		}
		var aC = am.decode(aK).split("|");
		var aF = aC.length;
		var ay;
		var az = "";
		for (var aD = 0; aD < aF; aD++) {
			ay = aC[aD].split("=");
			if (ay[0] == "NVKWD") {
				aG.push("NVKWD=" + ay[1])
			} else {
				if (ay[0] == "NVADKWD") {
					aG.push("NVADKWD=" + ay[1])
				} else {
					if (ay[0] == "NVAR") {
						aG.push("NVAR=" + ay[1])
					} else {
						if (ay[0] == "NVADID") {
							aG.push("NVADID=" + ay[1])
						} else {
							if (ay[0] == "t") {
								aG.push("t=" + ay[1]);
								var aM = "";
								var aA = parseInt(ay[1]);
								var aE = Math.round(aJ.getTime() / 1000);
								var ax = aE - aA;
								if (ax < 60 * 30 && aI == "1") {
									aM = "D"
								} else {
									if (ax < 60 * 60 * 24 * 15) {
										aM = "I"
									}
								}
								if (ax < 60 * 60 * 24 * 7) {
									aM += "C"
								}
								aG.push("isDirect=" + aM)
							} else {
								if (ay[0] == "u") {
									aG.push("u=" + ay[1])
								} else {
									if (ay[0] == "r") {
										aG.push("r=" + ay[1])
									}
								}
							}
						}
					}
				}
			}
		}
		aG.push("cnvType=" + aB);
		aG.push("cnvValue=" + aL);
		if (aM.indexOf("D") >= 0 || aM.indexOf("I") >= 0
				|| aM.indexOf("C") >= 0) {
			az = aG.join("|")
		}
		ae(af, am.encode("u=" + q(w) + "|r=" + q(C)), "", 0);
		return az
	}
	wcs.mileageWhitelist = [];
	function z() {
		var ay = aq ? aq.split("?")[1].split("&") : "";
		var aA = ay.length;
		var ax;
		var aB = "Ncisy";
		for (var az = 0; az < aA; az++) {
			ax = ay[az].split("=");
			if (ax[0] == aB) {
				return ax[1]
			}
		}
		return false
	}
	function ap() {
		var ax = (document.referrer) ? document.referrer : wcs.ref;
		if (ax.indexOf("naver.com") > 0) {
			return true
		}
		return false
	}
	function B(ax) {
		var aB = (document.referrer) ? document.referrer : wcs.ref;
		if (!aB) {
			return true
		}
		var az;
		if (ax == "m") {
			az = wcs.mileageWhitelist
		} else {
			if (ax == "c") {
				az = wcs.checkoutWhitelist
			}
		}
		var aA = az.length;
		az[aA] = "naver.com";
		az[aA + 1] = j;
		for (var ay = 0; ay < aA + 2; ay++) {
			if (aB.indexOf(az[ay]) >= 0) {
				return true
			}
		}
		return false
	}
	function ar(ax, ay, aA) {
		var az;
		az = parseInt(ay, aA);
		if (aA == 36) {
			az = az / 1000
		}
		if (Math.round(ax.getTime() / 1000) > az) {
			return true
		}
		return false
	}
	function b() {
		var ax = l(Q);
		return ax
	}
	function an(ax, az, aA) {
		var aB = am.encode(az);
		var ay = 0;
		ae(Q, aB, ax, ay, aA)
	}
	function D(ay, aE) {
		var ax, aB, aD, aC;
		if (!ay) {
			for (var aA = 0; aA < j.length; aA++) {
				if ((j.charCodeAt(aA) > 12592 && j.charCodeAt(aA) < 12687)
						|| (j.charCodeAt(aA) >= 44032 && j.charCodeAt(aA) <= 55203)) {
					al(Q, "", aE);
					return true
				}
			}
			ay = j.toLowerCase()
		}
		ax = ay.split(".");
		aB = ax.length;
		for (var aA = 0; aA < aB - 1; aA++) {
			aD = "";
			aC = [];
			for (var az = aA; az < aB; az++) {
				aC.push(ax[az])
			}
			aD = aC.join(".");
			al(Q, aD, aE)
		}
		return true
	}
	function L(ax) {
		return decodeURIComponent(ax.replace(/\+/g, " "))
	}
	function x(aC) {
		var ax, aB, ay;
		var aA = {};
		aC = L(aC);
		if (aC.length > 0) {
			ax = aC.split("|");
			aB = ax.length;
			for (var az = 0; az < aB; az++) {
				ay = ax[az].split("=");
				aA[ay[0]] = ay[1]
			}
		}
		return aA
	}
	function K(ax) {
		if ((ax !== undefined) && (ax !== "")) {
			return true
		} else {
			return false
		}
	}
	function e(aG) {
		var aC = new Date();
		var aA = z();
		var aD = a();
		var ay, aB, az;
		var ax = "", aH = "", aF = 0;
		var aI = "/";
		if (!aG) {
			aG = ""
		} else {
			var aE = S(aG);
			if (aE != false) {
				aG = aE[0];
				aI = aE[1]
			}
			if (j.indexOf(aG) < 0) {
				aG = ""
			}
		}
		if ((aD || aA) && ap()) {
			if (aD) {
				aB = x(aD);
				if (aB.et) {
					ax = aB.et;
					aF = 36
				}
				ncisy_napm = q("tr=" + aB.tr + "|et=" + aB.et + "|ba=" + aB.ba
						+ "|aa=" + aB.aa + "|ci=" + aB.ci + "|ct=" + aB.ct
						+ "|hk=" + aB.hk)
			} else {
				if (aA) {
					ay = x(aA);
					if (ay.e) {
						ax = ay.e;
						aF = 10
					}
				}
			}
			if (ax) {
				if (!ar(aC, ax, aF)) {
					if (aD) {
						if ((typeof aB != "undefined") && K(aB.tr) && K(aB.et)
								&& K(aB.ba) && K(aB.aa) && K(aB.ci) && K(aB.ct)
								&& K(aB.hk)) {
							an(aG, ncisy_napm, aI)
						}
					} else {
						if (aA) {
							an(aG, aA, aI)
						}
					}
				} else {
					D(aG, aI)
				}
			}
		} else {
			aH = b();
			if (aH) {
				aH = am.decode(aH);
				if (B("m")) {
					az = x(aH);
					if (az.v && az.e) {
						ax = az.e;
						aF = 10
					} else {
						if (az.et) {
							ax = az.et;
							aF = 36
						}
					}
					if (ar(aC, ax, aF)) {
						D(aG, aI)
					}
				} else {
					D(aG, aI)
				}
			}
		}
	}
	function A(aG) {
		var aE = false;
		var aA = new Date();
		aA.setTime(aA.getTime() + 1000 * 60 * 60 * 24);
		var ax = "naver_influx";
		var ay = "shopping.naver.com";
		var aD = a();
		var aC;
		var aH = "/";
		if (!aG) {
			aG = ""
		} else {
			var aF = S(aG);
			if (aF != false) {
				aG = aF[0];
				aH = aF[1]
			}
			if (j.indexOf(aG) < 0) {
				aG = ""
			}
		}
		var az = W.length;
		for (var aB = 0; aB < az; aB++) {
			if (C.indexOf(W[aB].replace("www.", "")) >= 0) {
				aE = true;
				break
			}
		}
		if (aE) {
			al(ab, aG, aH)
		} else {
			if (aD) {
				aC = x(aD);
				ax = q("ct=" + aC.ct + "|ci=" + aC.ci + "|tr=" + aC.tr + "|sn="
						+ aC.sn + "|hk=" + aC.hk)
			}
			if (C.indexOf(ay) >= 0) {
				ae(ab, ax, aG, aA.toGMTString(), aH)
			}
		}
	}
	function O() {
		var ay = l(ab);
		if (ay) {
			ay = L(ay);
			if (ay == "naver_influx") {
				return ay
			} else {
				var ax = x(ay);
				if (ax.sn && ax.ct && ax.ci && ax.hk) {
					return "&sn=" + ax.sn + "&st=" + ax.ct + "&si=" + ax.ci
							+ "&hk=" + ax.hk
				}
			}
		}
		return false
	}
	function ak(az) {
		var ay = "";
		var ax = O();
		ay = J(az, G);
		if (ax != "naver_influx") {
			ay += ax
		}
		ay += "&EOU";
		n(ay)
	}
	wcs.isCPA = l(ab);
	wcs.CPAOrder = ak;
	wcs.checkoutWhitelist = [];
	function ao(ax, aA, az) {
		var ay = 0;
		ae(U, aA, ax, ay, az)
	}
	function X() {
		var ax = l(U);
		return ax
	}
	function N(ax, ay) {
		al(U, ax, ay)
	}
	function F(ax) {
		var aB = "";
		var aA = "/";
		if (!ax) {
			ax = ""
		} else {
			var az = S(ax);
			if (az != false) {
				ax = az[0];
				aA = az[1]
			}
			if (j.indexOf(ax) < 0) {
				ax = ""
			}
		}
		var ay = a();
		if (ay) {
			napmObj = x(ay);
			aB = q("ct=" + napmObj.ct + "|ci=" + napmObj.ci + "|tr="
					+ napmObj.tr + "|hk=" + napmObj.hk + "|trx=" + napmObj.trx);
			ao(ax, aB, aA)
		} else {
			aB = X();
			if (aB && !B("c")) {
				N(ax, aA)
			}
		}
	}
	wcs.inflow = function(ax) {
		y(ax);
		e(ax);
		A(ax);
		F(ax)
	};
	wcs.cnv = M;
	wcs.getBaseAccumRate = function() {
		var ax = b();
		if (ax) {
			ax = am.decode(ax);
			ncisyObj = x(ax);
			if (ncisyObj.ba) {
				return ncisyObj.ba
			}
		}
		return 0
	};
	wcs.getAddAccumRate = function() {
		var ax = b();
		if (ax) {
			ax = am.decode(ax);
			ncisyObj = x(ax);
			if (ncisyObj.aa) {
				return ncisyObj.aa
			}
		}
		return 0
	};
	wcs.getMileageInfo = function() {
		var ax = b();
		if (ax) {
			ax = am.decode(ax);
			return ax
		}
		return false
	};
	wcs.getClickTime = function() {
		var ax = X();
		if (ax) {
			var ay = x(ax);
			if (ay.ct) {
				return ay.ct
			}
		}
		return false
	};
	wcs.getClickID = function() {
		var ax = X();
		if (ax) {
			var ay = x(ax);
			if (ay.ci) {
				return ay.ci
			}
		}
		return false
	};
	wcs.getInflowRoute = function() {
		var ax = X();
		if (ax) {
			var ay = x(ax);
			if (ay.tr) {
				return ay.tr
			}
		}
		return false
	};
	wcs.setReferer = function(ax) {
		wcs.ref = ax
	}
})();
var wcs_do = wcs.pageview;



																																									